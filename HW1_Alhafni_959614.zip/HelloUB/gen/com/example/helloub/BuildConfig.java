/** Automatically generated file. DO NOT MODIFY */
package com.example.helloub;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package com.example.relativelayout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class Intents  extends Activity {
	
	TextView one;
	Button changeBtn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.nested_layout);
		changeBtn = (Button) findViewById(R.id.button2);
		changeBtn.setOnClickListener(fore);
		one = (TextView)findViewById(R.id.textView1);
		
		Intent xx = getIntent();
		one.setText(xx.getStringExtra("helloKey"));
	}
	OnClickListener fore = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent weback = new Intent();
			weback.putExtra("past", "yay");
			setResult(0,weback);
			finish();
		}
	};
		
	
	
}


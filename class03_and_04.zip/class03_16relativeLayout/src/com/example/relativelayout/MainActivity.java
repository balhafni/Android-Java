package com.example.relativelayout;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity {

	Button changeBtn;
	Spinner spinner1;
	RelativeLayout rLayout;
	Context something;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		
		something = this;
		int longDuration = Toast.LENGTH_LONG;//3500
		int shortDuration = Toast.LENGTH_SHORT; //2000
		Toast theToast = Toast.makeText(something, "hello", shortDuration);
		int xOffset = 0;
		int yOffset = 0;
		theToast.setGravity(Gravity.CENTER|Gravity.TOP, xOffset, yOffset);
		//theToast.show();
		
		changeBtn = (Button) findViewById(R.id.button1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		rLayout = (RelativeLayout)findViewById(R.id.basicLayout);
		
		changeBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				Intent weird = new Intent(MainActivity.this, Intents.class);
				
				weird.putExtra("helloKey", "hello");
				//startActivity(weird);
				startActivityForResult(weird, 11);
			/*	List<String> list = new ArrayList<String>();
				list.add("broccoli");
				list.add("spinach");
				list.add("Onions");

				ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(
						MainActivity.this,
						android.R.layout.simple_spinner_item, list);
				spinnerAdapter
						.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
				spinner1.setAdapter(spinnerAdapter);
				spinner1.setPrompt("Select A Veggie");
				
				//rLayout.setVisibility(View.GONE);
				spinner1.setAlpha(0.5f);
				spinner1.setEnabled(false);
				*/
			}
		});

		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				switch (position) {
				case 0:
					changeBtn.setText("picked first item");
					Toast.makeText(something, "case 0", Toast.LENGTH_SHORT).show();
					break;
				case 1:
					changeBtn.setText("picked 2nd item");
					Toast rr = Toast.makeText(something, "case 0", Toast.LENGTH_SHORT);
					rr.setGravity(Gravity.CENTER|Gravity.TOP, 0, 0);
					rr.show();
					
					break;
				case 2:
					changeBtn.setText("picked 3rd item");
					break;
				case 3:
					changeBtn.setText("picked 4th item");
					break;

				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub

			}
		});
	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if ( requestCode == 11)
		{
			
			if (resultCode == 0)
			{
				changeBtn.setText("We are BAck!");
			}
			else if (resultCode == 1)
				changeBtn.setText("We fail!");
			
		}
		
	};
	
	
	
	
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}

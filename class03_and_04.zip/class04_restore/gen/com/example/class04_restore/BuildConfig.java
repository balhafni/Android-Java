/** Automatically generated file. DO NOT MODIFY */
package com.example.class04_restore;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
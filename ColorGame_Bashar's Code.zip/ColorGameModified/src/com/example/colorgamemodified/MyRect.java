package com.example.colorgamemodified;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.provider.MediaStore.Audio.GenresColumns;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.widget.Toast;

public class MyRect extends SurfaceView implements SurfaceHolder.Callback, Runnable {

	SurfaceHolder holder;
	boolean drawNow = true;
	Canvas canvas = null;
	boolean canDraw = false;
	Thread t = null;
	Paint paint;
	Rect red, blue, green, finish, bottom;
	int width, height;
	GestureDetector gesture;
	int change;

	public MyRect(Context context) {
		super(context);
		holder = getHolder();
		holder.addCallback(this);
		width = MainActivity.width;
		height = MainActivity.height;
		gesture = new GestureDetector(context, gestureListener);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (drawNow) {
			if (canDraw) {
				if (!holder.getSurface().isValid()) {
					continue;
				}
				change += 10;
				Canvas canvas = holder.lockCanvas();
				Log.v("size", canvas.getHeight() + "");
				drawRects(canvas);
				holder.unlockCanvasAndPost(canvas);
			}
			
		}
	}

	public boolean getGesture(MotionEvent e) {
		return gesture.onTouchEvent(e);
	}

	public void drawRects(Canvas c) {
		Paint paint = new Paint();
		red = new Rect((int) (width * 0.15), (int) (change + height * 0.1), (int) (width * 0.30),
				(int) (change + height * 0.21));
		paint.setColor(Color.RED);
		c.drawRect(red, paint);

		paint.setColor(Color.GREEN);
		green = new Rect((int) (width * 0.45), (int) (height * 0.1), (int) (width * 0.60), (int) (height * 0.21));
		c.drawRect(green, paint);
		Rect blue = new Rect((int) (width * 0.75), (int) (height * 0.1), (int) (width * 0.90), (int) (height * 0.21));
		paint.setColor(Color.BLUE);

		c.drawRect(blue, paint);
		// // drawing the finish line
		finish = new Rect(0, (int) (height * 0.7), (int) (width), (int) (height * 0.73));
		paint.setColor(Color.GRAY);

		c.drawRect(finish, paint);
		// drawing the bottom rectangle
		bottom = new Rect(0, (int) (height * 0.78), (int) (width), (int) (height));
		paint.setColor(Color.BLUE);
		c.drawRect(bottom, paint);
	}

	private void tryDrawing(SurfaceHolder holder) {

		Canvas canvas = holder.lockCanvas();
		if (canvas == null) {

		} else {
			drawRects(canvas);
			holder.unlockCanvasAndPost(canvas);
		}
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		tryDrawing(holder);
		newGame(holder);
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub

	}

	public void newGame(SurfaceHolder holder) {

		t = new Thread(this);
		t.start();

	}

	SimpleOnGestureListener gestureListener = new SimpleOnGestureListener() {
		@Override
		public boolean onDoubleTap(MotionEvent event) {
			Log.v("gesture", "double tap");
			return true;
		}

		@Override
		public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY) {
			int x = (int) event1.getX();
			int y = (int) event1.getY();
			System.out.println("x is: " + x);
			Log.v("motion", x + "");
			System.out.println("y is: " + y);
			System.out.println("bla : " + width * 0.15);
			System.out.println("blabla : " + width * 0.45);
			if (x >= (int) (width * 0.15) && x <= (int) (width * 0.30)) {
				System.out.println("I'm red");
				canDraw = true;
			} else if (x >= (int) (width * 0.45) && x <= (int) (width * 0.60)) {
				System.out.println("I'm green");
			} else {
				System.out.println("I'm blue");
			}
			return true;

		}
	};

}
